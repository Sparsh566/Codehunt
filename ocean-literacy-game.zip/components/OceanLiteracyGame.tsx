"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { Waves, Droplet, Award, RefreshCw, Clock } from "lucide-react"

const questions = [
  {
    question: "What percentage of Earth's surface is covered by oceans?",
    answers: ["50%", "60%", "70%", "80%"],
    correctAnswer: "70%",
  },
  {
    question: "Which of these is NOT one of the five ocean basins?",
    answers: ["Atlantic", "Pacific", "Indian", "Mediterranean"],
    correctAnswer: "Mediterranean",
  },
  {
    question: "What is the primary driver of global climate and weather?",
    answers: ["Mountains", "Deserts", "Oceans", "Forests"],
    correctAnswer: "Oceans",
  },
  {
    question: "What percentage of the oxygen we breathe comes from the ocean?",
    answers: ["25%", "50%", "75%", "90%"],
    correctAnswer: "50%",
  },
  {
    question: "Which of these is NOT a threat to ocean health?",
    answers: ["Overfishing", "Plastic pollution", "Climate change", "Increased marine protected areas"],
    correctAnswer: "Increased marine protected areas",
  },
]

export default function OceanLiteracyGame() {
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [score, setScore] = useState(0)
  const [showScore, setShowScore] = useState(false)
  const [selectedAnswer, setSelectedAnswer] = useState("")
  const [timeLeft, setTimeLeft] = useState(60) // 60 seconds per game

  useEffect(() => {
    if (timeLeft > 0 && !showScore) {
      const timerId = setTimeout(() => setTimeLeft(timeLeft - 1), 1000)
      return () => clearTimeout(timerId)
    } else if (timeLeft === 0 && !showScore) {
      setShowScore(true)
    }
  }, [timeLeft, showScore])

  const handleAnswerClick = (answer: string) => {
    setSelectedAnswer(answer)
    if (answer === questions[currentQuestion].correctAnswer) {
      setScore(score + 1)
    }

    const nextQuestion = currentQuestion + 1
    if (nextQuestion < questions.length) {
      setTimeout(() => {
        setCurrentQuestion(nextQuestion)
        setSelectedAnswer("")
      }, 1500)
    } else {
      setShowScore(true)
    }
  }

  const restartGame = () => {
    setCurrentQuestion(0)
    setScore(0)
    setShowScore(false)
    setSelectedAnswer("")
    setTimeLeft(60)
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-400 to-blue-600 flex items-center justify-center p-4 relative overflow-hidden">
      <div className="absolute inset-0 z-0">
        <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
          <path
            fill="rgba(255,255,255,0.3)"
            fillOpacity="1"
            d="M0,96L48,112C96,128,192,160,288,186.7C384,213,480,235,576,213.3C672,192,768,128,864,128C960,128,1056,192,1152,208C1248,224,1344,192,1392,176L1440,160L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"
          ></path>
        </svg>
      </div>
      <div className="bg-white bg-opacity-90 rounded-2xl shadow-2xl p-8 max-w-md w-full z-10 backdrop-blur-sm">
        <h1 className="text-3xl font-bold text-center mb-6 text-blue-800">Ocean Literacy Quiz</h1>
        <div className="flex justify-between items-center mb-4">
          <div className="flex items-center">
            <Clock className="text-blue-500 w-5 h-5 mr-1" />
            <span className="text-sm font-medium text-gray-600">Time: {timeLeft}s</span>
          </div>
          <div className="flex items-center">
            <Droplet className="text-blue-500 w-5 h-5 mr-1" />
            <span className="text-sm font-medium text-gray-600">Score: {score}</span>
          </div>
        </div>
        {showScore ? (
          <div className="text-center">
            <h2 className="text-2xl font-bold mb-4 text-blue-700">Game Over!</h2>
            <div className="flex items-center justify-center mb-4">
              <Award className="text-yellow-500 w-16 h-16 mr-2" />
              <p className="text-3xl font-bold text-blue-700">
                {score} / {questions.length}
              </p>
            </div>
            <motion.button
              onClick={restartGame}
              className="bg-blue-500 text-white px-6 py-3 rounded-full text-lg font-semibold hover:bg-blue-600 transition-colors flex items-center justify-center mx-auto"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <RefreshCw className="mr-2" />
              Play Again
            </motion.button>
          </div>
        ) : (
          <>
            <div className="mb-6">
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium text-gray-600">
                  Question {currentQuestion + 1}/{questions.length}
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-3">
                <motion.div
                  className="bg-blue-500 h-3 rounded-full"
                  initial={{ width: 0 }}
                  animate={{ width: `${((currentQuestion + 1) / questions.length) * 100}%` }}
                  transition={{ duration: 0.5 }}
                ></motion.div>
              </div>
            </div>
            <h2 className="text-xl font-bold mb-4 text-blue-800">{questions[currentQuestion].question}</h2>
            <div className="space-y-3">
              {questions[currentQuestion].answers.map((answer, index) => (
                <motion.button
                  key={index}
                  onClick={() => handleAnswerClick(answer)}
                  className={`w-full text-left p-4 rounded-lg text-lg font-medium ${
                    selectedAnswer === answer
                      ? answer === questions[currentQuestion].correctAnswer
                        ? "bg-green-500 text-white"
                        : "bg-red-500 text-white"
                      : "bg-blue-100 text-blue-800 hover:bg-blue-200"
                  } transition-colors`}
                  disabled={selectedAnswer !== ""}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  {answer}
                </motion.button>
              ))}
            </div>
          </>
        )}
      </div>
      <Waves className="absolute bottom-4 left-4 text-white opacity-50 w-12 h-12" />
    </div>
  )
}

