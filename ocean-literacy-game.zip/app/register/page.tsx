import Layout from "../../components/Layout"
import Register from "../../components/Register"

export default function RegisterPage() {
  return (
    <Layout>
      <Register />
    </Layout>
  )
}

