import Layout from "../components/Layout"
import OceanLiteracyGame from "../components/OceanLiteracyGame"

export default function Home() {
  return (
    <Layout>
      <OceanLiteracyGame />
    </Layout>
  )
}

